<template>
  <div id="app">

    <nav class="navbar navbar-expand-lg navbar-light sticky-top " id="mainNav">
      <div class="container-fluid">

        <a class="navbar-brand ml-0" href="/home">
          <img src="@/assets/image/navbar-logo.svg" alt="..."/>
        </a>

        <button class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarToggleExternalContent"
                aria-controls="navbarToggleExternalContent"
                aria-expanded="false"
                aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"> </span>
        </button>

      </div>


      <div class="collapse navbar-collapse" id="navbarToggleExternalContent">
        <div>
          <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
            <li class="nav-item">
              <router-link to="/home" class="nav-link">
                Home
              </router-link>
              <!-- 갈맷길 코스 -->
            <li class="nav-item">
              <a
                  class="nav-link dropdown-toggle"
                  href="#"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false">
                갈맷길
              </a>
              <div class="dropdown">
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <router-link to="/galinfo" class="dropdown-item">
                    갈맷길이란?
                  </router-link>
                  <router-link to="/course1" class="dropdown-item">
                    1코스
                  </router-link>
                  <router-link to="/course2" class="dropdown-item">
                    2코스
                  </router-link>
                  <router-link to="/course3" class="dropdown-item">
                    3코스
                  </router-link>
                  <router-link to="/course4" class="dropdown-item">
                    4코스
                  </router-link>
                  <router-link to="/course5" class="dropdown-item">
                    5코스
                  </router-link>
                  <router-link to="/course6" class="dropdown-item">
                    6코스
                  </router-link>
                  <router-link to="/course7" class="dropdown-item">
                    7코스
                  </router-link>
                  <router-link to="/course8" class="dropdown-item">
                    8코스
                  </router-link>
                  <router-link to="/course9" class="dropdown-item">
                    9코스
                  </router-link>
                </div>
              </div>
            </li>

            <!-- 플로깅 -->
            <li class="nav-item">
              <router-link to="/plogging" class="nav-link">
                플로깅
              </router-link>
            </li>

            <!-- 게시판 -->
            <li class="nav-item">
              <router-link to="/home" class="nav-link">
                갤러리
              </router-link>
            </li>

            <!-- login -->
            <div v-if="!currentUser">
              <li class="nav-item">
                <div class="portfolio-item">
                  <a class="portfolio-link nav-link" data-bs-toggle="modal" href="#LoginPage">
                    로그인
                  </a>
                  <!--                  <router-link to="/login">-->
                  <!--                    로그인-->
                  <!--                  </router-link>-->
                </div>
              </li>
            </div>

            <!-- 회원가입 -->
            <div v-if="!currentUser">
              <li class="nav-item">
                <div class="portfolio-item">
                  <a class="portfolio-link nav-link" data-bs-toggle="modal" href="#RegisterPage">
                    회원가입
                  </a>
                </div>
              </li>
            </div>

            <!-- logOut -->
            <div v-if="currentUser">
              <li class="nav-item">
                <div class="portfolio-item">
                  <router-link to="profile" class="nav-link">
                    {{ currentUser.username }}
                  </router-link>
                </div>
              </li>
            </div>

            <!-- 회원가입 -->
            <div v-if="currentUser">
              <li class="nav-item">
                <div class="portfolio-item">
                  <a class="portfolio-link nav-link" href @click.prevent="logOut()">
                    로그아웃
                  </a>
                </div>
              </li>
            </div>



          </ul>

        </div>
      </div>

    </nav>


    <router-view/>
    <div class="container">
    </div>
  </div>
</template>


<script>

export default {
  name: "app",

  //html에서 변수처럼 호출: 뒤에 () 붙이면 안됨
  //속도는 computed가 빠름
  computed: {
    currentUser() {
      //공유저장소의 전역변수(공유변수 : user)
      //자동으로 로그인이 되었으면 loggedIn = true, user = user
      //아니면 loggedIn = false, user = null
      return this.$store.state.auth.user;
      // return true;
    }
  },
  //html에서 함수처럼 호출: 뒤에 () 붙음
  methods: {
    logOut() {
      //dispatch 호줄하는 메서드 : actions에 있는 메서드를 호출함
      this.$store.dispatch("auth/logout")
      //로그아웃 후 이동 할 페이지 지정
      this.$router.push("/login")
    }
  },
};
</script>

<style scoped>

</style>
