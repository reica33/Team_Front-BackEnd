<template>
  <div>
    <!--  &lt;!&ndash;폴리나&ndash;&gt;-->
    <main class="mypage">
      <section
          class="profile"
          aria-label="profile">
        <div class="profile__people">
          <img
              class="profile__avatar"
              src="@/assets/img/portfolio/portfolio-4.jpg"
              alt="profile photo">

          <div class="profile__info">
            <h1 class="profile__name">{{currentUser.username}}</h1>
            <button
                class="open-popup profile__edit-button"
                type="button"
                aria-label="edit button"></button>
          </div>
        </div>
        <button
            class="open-popup profile__add-button"
            type="button"
            aria-label="add button"></button>

      </section>
      <section class="card__number">

        <h2 class="element__number"></h2>
        <p class="elements__sum_title"> 번의 플로깅에 동참하셨습니다.</p>
      </section>
      <section
          class="elements"
          aria-label="photo">

        <div
            id="element-template"
            class="card">

          <article class="element">

            <button
                type="button"
                class="element__trash"
                aria-label="delete button"></button>
            <img
                src="#"
                class="element__image"
                alt="">
          </article>
        </div>
      </section>
    </main>

    <div class="popup-edit popup">
      <div class="popup__container">
        <button
            type="button"
            class="popup-edit__close-button popup__close-button"></button>
        <h2 class="popup__title">
          Edit name
        </h2>

        <form
            class="popup__form form-edit form"
            name="edit-form"
            id="form-edit" novalidate>
          <input
              v-model="mes"
              id="form__input-text"
              type="text"
              name="name"
              class="popup__input popup__input_value_name form__input"
              placeholder="이름"
              value=""
              minlength="2"
              maxlength="40" required>
          <span class="form__input-text-error"></span>

          <button
              type="submit"
              class="popup__button"
          >
            Save
          </button>
        </form>
      </div>
    </div>

    <div class="popup popup-add">
      <div class="popup__container">
        <button
            type="button"
            class="popup-add__close-button popup__close-button"></button>

        <h2 class="popup__title">New Card</h2>

        <form
            class="popup__form form-add form"
            name="add-form"
            id="form-add" novalidate>

          <input
              v-model="url"
              type="url"
              name="link"
              id="form__input-link"
              class="popup__input popup__input_value_link form__input"
              value=""
              placeholder="link" required>
          <span class="form__input-link-error"></span>

          <button
              type="submit"
              class="popup__button popup-add__button form__button"
          >
            Add card
          </button>
        </form>
      </div>
    </div>


    <div class="popup popup-image">
      <article class="popup-image__element">
        <button
            type="button"
            class="popup__close-button popup-image__close-button"></button>
        <img src="#"
             class="popup-image__image"
             alt="">
        <h2 class="popup-image__title"></h2>
      </article>
    </div>


    <!--  효경-->
    <!--  부트스트랩 container => 컨텐츠를 박스형태로 보여줌-->
    <div class="container">
      <header class="jumbotron">
        <h3>
          <strong>{{ currentUser.username }}</strong> Profile
        </h3>
      </header>

      <p>
        <strong> Id </strong>
        {{ currentUser.id }}
      </p>

      <p>
        <strong> E-Mail </strong>
        {{ currentUser.email }}
      </p>


      <div>
        <!-- TODO: 수정 필요 -->
        <!-- row 시작 -->
        <div class="row justify-content-md-center">

          <div class="col-3">
            <!--    Todo : page 바 시작 -->
            <div class="col-md-12">
              <div class="mb-3">
                Items per Page:
                <select v-model="pageSize" @change="handlePageSizeChange($event)">
                  <option v-for="size in pageSizes" :key="size" :value="size">
                    <!--            size : 3, 6, 9 -->
                    {{ size }}
                  </option>
                </select>
              </div>

              <b-pagination v-model="page" :total-rows="count" :per-page="pageSize"
                            prev-text="Prev" next-text="Next" @change="handlePageChange"
              >
              </b-pagination>
            </div>
            <!--    Todo : page 바 끝 -->
            <div class="mb-3">
              <label class="btn btn-default p-0">
                <!-- 파일 선택상자 -->
                <input
                    type="file"
                    accept="image/*"
                    ref="file"
                    @change="selectImage"
                />
              </label>
            </div>
            <div class="mb-3">
              <!-- 서버에 insert 문 호출 -->
              <button
                  class="btn btn-success btn-sm float-left"
                  :disabled="!currentImage"
                  @click="upload"
              >
                Upload
              </button>
            </div>
          </div>
        </div>
        <!-- row 끝 -->

        <!-- 프로그래스 바 시작-->
        <div v-if="currentImage" class="progress">
          <div
              class="progress-bar progress-bar-info"
              role="progressbar"
              :style="{ width: progress + '%' }"
              :aria-valuenow="progress"
              aria-valuemin="0"
              aria-valuemax="100"
          >
            {{ progress }}%
          </div>
        </div>
        <!-- 프로그래스 바 끝-->

        <!-- 미리보기 이미지 시작-->
        <div v-if="previewImage">
          <div>
            <img class="preview my-3" :src="previewImage" alt=""/>
          </div>
        </div>
        <!--  미리보기 이미지 끝 -->

        <!-- 서버 에러 메세지가 있을경우 아래 출력 -->
        <div v-if="message" class="alert alert-secondary" role="alert">
          {{ message }}
        </div>

        <!-- 쇼핑 카트 형태 디자인 -->
        <!-- v-for 시작 -->
        <div class="card mt-3"
             v-for="(image, index) in imageInfo"
             :key="index"
        >
          <div class="card-header">이미지 번호 : {{ index }}</div>
          <div class="row">
            <div class="col-md-5 col-md-offset-0">
              <figure>
                <img class="img-thumbnail" :src="image.url"/>
              </figure>
            </div>

          </div>
        </div>
      </div>

    </div>
  </div>

</template>

<script>

import UploadFilesService from "../services/UploadFilesService";
import myPage from "@/assets/js/index";


/*eslint-disable*/

export default {
  name: "Profile",

  data() {
    // 변수 초기화
    return {
      currentImage: undefined, // 현재이미지
      previewImage: undefined, // 미리보기 이미지
      progress: 0, // 프로그래스바를 위한 변수
      message: "",
      mes: "",
      imageInfo: [], // 이미지 정보 객체배열
      // todo: 이미지와 변수 같이 보내기
      // Todo : 아래 변수 추가
      page: 1,
      count: 0,
      pageSize: 3,
      pageSizes: [3, 6, 9],
      username: "",
      url: "",
    };
  },

  methods: {
    // Todo : getRequestParams 추가
    getRequestParams(username, page, pageSize) {
      let params = {};

      if (username) {
        params["username"] = username;
      }

      if (page) {
        params["page"] = page - 1;
      }

      if (pageSize) {
        params["size"] = pageSize;
      }

      return params;
    },
    // todo :
    retrieveUpload() {
      // Todo : getRequestParams 호출 추가
      const params = this.getRequestParams(
          this.currentUser.username,
          this.page,
          this.pageSize
      );

      UploadFilesService.getFiles(params)
          // 성공하면 then에 들어옴(객체, 응답메세지)
          .then((response) => {
            // response.data : 서버쪽에서 전송된 객체
            this.imageInfo = response.data;
            this.count = this.imageInfo[0].totalItems;


            // const {imageInfo, totalItems} = response.data;
            // this.imageInfo = imageInfo;
            // this.count = totalItems;

          });
    },
    // 이미지를 선택하면 변수에 저장하는 메소드
    selectImage() {
      // 파일선택상자에서 첫번째로 선택한 이미지가 저장됨
      this.currentImage = this.$refs.file.files.item(0);
      // 아래는 미리보기 이미지를 위한 주소가 저장됨
      this.previewImage = URL.createObjectURL(this.currentImage);
      this.progress = 0;
      this.message = "";
    },
    // 파일 업로드를 위한 메소드
    upload() {
      this.progress = 0;

      // 서버에 이미지 업로드 요청(insert 문 실행)
      UploadFilesService.upload(this.currentUser.username, this.currentImage, (event) => {
        // 파일이 업로드될때 진척상황이 저장됨(%)
        this.progress = Math.round((100 * event.loaded) / event.total);
      })
          // 성공하면 then 으로 들어옴(서버에서 응답한 객체)
          .then((response) => {
            const params = this.getRequestParams(
                this.currentUser.username,
                this.page,
                this.pageSize
            );
            // 서버쪽 응답 메시지 저장
            this.message = response.data.message;
            // 서버쪽에 insert가 잘되었는지
            // select문 호출
            return UploadFilesService.getFiles(params);
          })
          // 성공하면 then으로 들어옴(서버쪽 객체 받음)
          .then((image) => {
            this.imageInfo = image.data;
          })
          // 실패하면 catch으로 들어옴
          // 화면에 실패메세지 출력
          .catch((err) => {
            this.progress = 0;
            this.message = "Could not upload the image!" + err;
            this.currentImage = undefined;
          });
    },
    // Todo : handlePageChange, handlePageSizeChange
    handlePageChange(value) {
      this.page = value;
      this.retrieveUpload();
    },

    handlePageSizeChange(event) {
      this.pageSize = event.target.value;
      this.page = 1;
      this.retrieveUpload();
    },
  },

  computed: {
    currentUser() {
      return this.$store.state.auth.user;
      // return true;
    }
  },
  //화면이 뜨자마자 실행되는 이벤트
  mounted() {

    //사용자가 로그인 하지 않은 경우 로그인페이지로 강제이동
    if (!this.currentUser) {
      //로그인 페이지로 강제 이동 시킴
      this.$router.push("/login");
    }
    this.retrieveUpload(),
    myPage();
  }

}</script>

<style scoped>
@import "@/assets/css/mypage.css";
@import "@/assets/css/popup.css";
@import "@/assets/css/elements.css";

</style>