<template>
  <div>
    <footer class="footer py-4">
      <div class="container mt-5 pt-5">
        Copyright &copy; JoopGing 2022
      </div>
    </footer>

  </div>
</template>

<script>
export default {
  name: "FooterCom"
}
</script>

<style scoped>

</style>