<template>
  <div>

    <!-- Masthead-->
    <header class="masthead">
      <div class="container mt-5 pt-5" id="box">
      </div>
    </header>

  </div>

</template>

<script>
export default {
  name: "HeaderCom"
}
</script>

<style scoped>

</style>