<template>
  <div class="container-fluid">
    <!-- plogging -->
    <router-link to="/plogging">
      <img src="@/assets/img/ploggingMain.png" class="plogging"/>
    </router-link>



  </div>
</template>

<script>
export default {
  name: "SectionCom",

}
</script>

<style scoped>

</style>