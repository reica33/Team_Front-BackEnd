<template>
  <div id="page-top">
    <!-- Navigation-->
    <!--    bootstrap : m(margin), l(left), r(right), t(top), b(bottom) -1,2,3,4,5 -->
    <a class="menu-toggle">
    </a>


    <!-- HeaderCom -->
    <MainMap/>

    <!-- 플로깅 -->
    <PloggingCom/>

    <!--  갤러리  -->
    <GalluryCom/>

    <!-- Login  -->
    <Login/>

    <!-- Register  -->
    <Register/>

    <!-- Footer -->
    <FooterCom/>


  </div>
</template>

<script>
// Todo: bootstrap 테마 js 적용
import start from "@/assets/js/scripts2"
import loadWin from "@/assets/js/scripts"
import HeaderCom from "@/components/home/HeaderCom";
import FooterCom from "@/components/home/FooterCom";
import PloggingCom from "@/components/home/PloggingCom";
import GalluryCom from "@/components/home/GalluryCom";
import MainMap from "@/components/home/MainMap";
import Login from "@/components/home/LoginMD";
import Register from "@/components/home/RegisterMD";

export default {
  name: 'HomeView',
  components: {
    MainMap,
    PloggingCom,
    GalluryCom,
    FooterCom,
    HeaderCom,
    Login,
    Register
  },
  mounted() {
    loadWin();
    start();
  }
}
</script>

<style>

</style>
