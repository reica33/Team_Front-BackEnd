<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */
export default {
  name: "Course1"
}
</script>

<style scoped>

</style>