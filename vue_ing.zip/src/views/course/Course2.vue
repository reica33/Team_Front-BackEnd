<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course2"
}
</script>

<style scoped>

</style>