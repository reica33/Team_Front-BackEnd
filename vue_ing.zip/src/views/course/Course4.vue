<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course4"
}
</script>

<style scoped>

</style>