<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course5"
}
</script>

<style scoped>

</style>