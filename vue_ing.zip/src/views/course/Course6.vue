<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course6"
}
</script>

<style scoped>

</style>