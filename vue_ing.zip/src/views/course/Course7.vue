<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course7"
}
</script>

<style scoped>

</style>