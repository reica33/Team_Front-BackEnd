<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "Course9"
}
</script>

<style scoped>

</style>