<template>
  <div>

  </div>
</template>

<script>
/* eslint-disable */

export default {
  name: "GalInfo"
}
</script>

<style scoped>

</style>