<template>
  <section class="page-section" id="about">
    <div class="banner">
      <img src="@/assets/img/plogging/plogging_main_blue.png" class="img-fluid" />
    </div>
    <br />
    <br />
    <br />
    <div class="step-button">
      <nav id="navbar-example">
        <ul class="top-scroll">
          <li class="button-item">
            <a class="button-link" href="#step1"
            ><img class="img-responsive" src="@/assets/img/plogging/STEP1.png" alt="..."
            /></a>
          </li>
          <li class="button-item">
            <a class="button-link" href="#step2"
            ><img class="img-responsive" src="@/assets/img/plogging/STEP2.png" alt="..."
            /></a>
          </li>
          <li class="button-item">
            <a class="button-link" href="#step3"
            ><img class="img-responsive" src="@/assets/img/plogging/STEP3.png" alt="..."
            /></a>
          </li>
          <li class="button-item">
            <a class="button-link" href="#step4"
            ><img class="img-responsive" src="@/assets/img/plogging/STEP4.png" alt="..."
            /></a>
          </li>
        </ul>
      </nav>
    </div>
    <br />
    <br />
    <br />
    <div class="timeline-panel">
      <div class="container text-box">
        <div class="table-responsive">
          <table class="table">
            <tr style="border-top: none" align="center">
              <td style="border-top: none" rowspan="4">
                <img class="img-fluid" src="@/assets/img/plogging/plogging_list1.png" />
              </td>
            </tr>
            <tr style="border-top: none">
              <td style="border-top: none" rowspan="4">
                <div
                    data-spy="scroll"
                    data-target="#navbar-example"
                    data-offset="0"
                    class="scrollspy-step"
                >
                  <h1 id="step1" class="plogging-title">
                    STEP 1. 플로깅이 무엇인가요?
                  </h1>
                </div>
                <div class="plogging-content">
                  <p>
                    <b>01. Plogging</b>
                  </p>
                  '이삭줍기'를 뜻하는 스웨덴어 플로카 우프(Plocka Upp)와
                  영어단어 jogging(조깅)의 합성어.<br /><br />
                  <p>
                    <b>02. 환경보호 운동</b>
                  </p>
                  조깅을 하면서 동시에 쓰레기를 줍는 운동으로, 스웨덴에서
                  시작되어 북유럽을<br />
                  중심으로 확산되었으며 건강과 환경을 동시에 챙길 수 있다.
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <br />
    <br />
    <div class="container"></div>
    <br />
    <br />
    <div class="timeline-panel">
      <div class="container text-box2">
        <div class="timeline-heading2">
          <div
              data-spy="scroll"
              data-target="#navbar-example"
              data-offset="0"
              class="scrollspy-step"
          >
            <h1 id="step2" align="center" class="plogging-title">
              STEP 2. 플로깅 시작 전 꼭 챙기세요!
            </h1>
          </div>
          <br />
        </div>
        <div class="timeline-body">
          <img
              class="img-fluid"
              src="@/assets/img/plogging/plogging_prep2.png"
              alt="..."
          />
        </div>
      </div>
    </div>
    <br />
    <br />
    <div class="container"></div>
    <br />
    <br />
    <div class="timeline-panel">
      <div class="container text-box">
        <div class="table-responsive">
          <table class="table">
            <tr style="border-top: none" align="left">
              <td style="border-top: none" rowspan="4">
                <div
                    data-spy="scroll"
                    data-target="#navbar-example"
                    data-offset="0"
                    class="scrollspy-step"
                >
                  <h1 id="step3" class="plogging-title">
                    STEP 3. 플로깅 하는 방법
                  </h1>
                </div>
                <div class="plogging-content2">
                  <p>
                    <b
                    >01) 조깅하러 나가기 전 종량제 봉투나 쓰지 않는 에코백,
                      장갑, 집게 등을 챙긴다.</b
                    >
                  </p>
                  <br />
                  <p>
                    <b>02) 조깅을 하며 쓰레기를 주워 봉투에 담는다.</b>
                  </p>
                  <br />
                  <p>
                    <b
                    >03) 모인 쓰레기는 반드시 본인이 챙겨 가서 규격에 맞게
                      분리수거를 한다.</b
                    >
                  </p>
                  <p></p>
                </div>
              </td>
            </tr>
            <tr style="border-top: none">
              <td style="border-top: none" rowspan="4">
                <img class="img-fluid" src="@/assets/img/plogging/plogging_list2.png" />
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    <br />
    <br />
    <div class="container"></div>
    <br />
    <br />
    <div class="timeline-panel">
      <div class="container text-box">
        <div class="table-responsive">
          <table class="table">
            <tr style="border-top: none" align="center">
              <td style="border-top: none" rowspan="4">
                <img class="img-fluid" src="@/assets/img/plogging/plogging_list3.png" />
              </td>
            </tr>
            <tr style="border-top: none">
              <td style="border-top: none" rowspan="4">
                <div
                    data-spy="scroll"
                    data-target="#navbar-example"
                    data-offset="0"
                    class="scrollspy-step"
                >
                  <h1 id="step4" class="plogging-title">
                    STEP 4. 플로깅의 좋은점
                  </h1>
                </div>
                <div class="plogging-content">
                  <p>
                    <b>01. 체력 단련</b>
                  </p>
                  달리다가 쓰레기를 주울 때 하체를 굽히는 모양이<br />스쿼트나
                  런지 운동과 비슷하여 조깅만 하는 것보다 더 큰 운동 효과를 볼
                  수 있다.<br /><br />
                  <p>
                    <b>02. 환경 보호</b>
                  </p>
                  활발한 플로깅을 통해 환경 쓰레기 감소와 사회인들의 건강 증진,
                  그리고 <br />주변 환경이 좋은 방향으로 개선될 수 있다.
                  <br />
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <br />
    <br />
    <div class="container"></div>
  </section>
</template>

<script>
/* eslint-disable */
export default {
  name: "Plogging",
};
</script>

<style scoped>

</style>
